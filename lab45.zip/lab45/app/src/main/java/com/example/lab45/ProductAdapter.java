package com.example.lab45;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lab45.Product;
import com.example.lab45.R;

import java.util.ArrayList;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {

    private ArrayList<Product> productList;

    public ProductAdapter(ArrayList<Product> productList) {
        this.productList = productList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Product product = productList.get(position);
        holder.textItemTitle.setText(product.getTitle());
        holder.textItemPrice.setText("Price: $" + product.getPrice());
        holder.textItemRating.setText("Rating: " + product.getRating().getRate());
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textItemTitle, textItemPrice, textItemRating;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textItemTitle = itemView.findViewById(R.id.Title);
            textItemPrice = itemView.findViewById(R.id.Price);
            textItemRating = itemView.findViewById(R.id.Rating);
        }
    }
}