package com.example.lab45;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class GetAppProductTask extends AsyncTask<String, Void, String> {

    private ArrayList<Product> productArrayList;
    private ProductAdapter productsAdapter;

    public GetAppProductTask(ArrayList<Product> productArrayList, ProductAdapter productsAdapter) {
        this.productArrayList = productArrayList;
        this.productsAdapter = productsAdapter;
    }

    public GetAppProductTask() {

    }

    @Override
    protected String doInBackground(String... urls) {
        StringBuilder result = new StringBuilder();
        try {
            URL url = new URL(urls[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result.toString();
    }

    @Override
    protected void onPostExecute(String result) {
        try {
            JSONArray jsonArray = new JSONArray(result);
            productArrayList.clear(); // Очистка перед добавлением новых данных

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject productObj = jsonArray.getJSONObject(i);
                JSONObject ratingObj = productObj.getJSONObject("rating");

                Rating rating = new Rating(
                        (float) ratingObj.getDouble("rate"),
                        ratingObj.getInt("count")
                );

                productArrayList.add(new Product(
                        productObj.getInt("id"),
                        productObj.getString("title"),
                        (float) productObj.getDouble("price"),
                        productObj.getString("description"),
                        productObj.getString("category"),
                        productObj.getString("image"),
                        rating
                ));
            }

            productsAdapter.notifyDataSetChanged();

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
