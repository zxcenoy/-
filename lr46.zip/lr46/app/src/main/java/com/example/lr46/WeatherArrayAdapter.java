package com.example.lr46;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class WeatherArrayAdapter extends ArrayAdapter<Weather> {
    private final Map<String, Bitmap> bitmaps = new HashMap<>();

    public WeatherArrayAdapter(Context context, List<Weather> weatherList) {
        super(context, -1, weatherList);
    }

    private static class ViewHolder {
        ImageView conditionImageView;
        TextView dayTextView;
        TextView timeTextView;
        TextView lowTextView;
        TextView hiTextView;
        TextView humidityTextView;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Weather weather = getItem(position);
        ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
            holder.conditionImageView = convertView.findViewById(R.id.conditionImageView);
            holder.dayTextView = convertView.findViewById(R.id.dayTextView);
            holder.timeTextView = convertView.findViewById(R.id.timeTextView);
            holder.lowTextView = convertView.findViewById(R.id.lowTextView);
            holder.hiTextView = convertView.findViewById(R.id.hiTextView);
            holder.humidityTextView = convertView.findViewById(R.id.humidityTextView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        if (bitmaps.containsKey(weather.iconURL)) {
            holder.conditionImageView.setImageBitmap(bitmaps.get(weather.iconURL));
        } else {
            new LoadImageTask(holder.conditionImageView).execute(weather.iconURL);
        }

        holder.dayTextView.setText(weather.dayOfWeek);
        holder.timeTextView.setText(weather.time);
        holder.lowTextView.setText(getContext().getString(R.string.low_temp, weather.minTemp));
        holder.hiTextView.setText(getContext().getString(R.string.high_temp, weather.maxTemp));
        holder.humidityTextView.setText(getContext().getString(R.string.humidity, weather.humidity));

        return convertView;
    }

    private class LoadImageTask extends AsyncTask<String, Void, Bitmap> {
        private final ImageView imageView;
        private String url;

        LoadImageTask(ImageView imageView) {
            this.imageView = imageView;
        }

        @Override
        protected Bitmap doInBackground(String... params) {
            url = params[0];
            try {
                URL imageURL = new URL(url);
                HttpsURLConnection connection = (HttpsURLConnection) imageURL.openConnection();
                InputStream input = connection.getInputStream();
                Bitmap bitmap = BitmapFactory.decodeStream(input);
                bitmaps.put(url, bitmap);
                connection.disconnect();
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
            }
        }
    }
}

