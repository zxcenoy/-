package com.example.lr46;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class Weather {
    public final String dayOfWeek;
    public final String time;
    public final String minTemp;
    public final String maxTemp;
    public final String humidity;
    public final String description;
    public final String iconURL;

    public Weather(long timestamp, double minTemp, double maxTemp, int humidity,
                   String description, String icon) {
        NumberFormat numberFormat = NumberFormat.getInstance();
        numberFormat.setMaximumFractionDigits(0);

        this.dayOfWeek = convertTimeStampToDay(timestamp);
        this.time = convertTimeStampToTime(timestamp);
        this.minTemp = numberFormat.format(minTemp) + "\u00B0C";
        this.maxTemp = numberFormat.format(maxTemp) + "\u00B0C";
        NumberFormat percentFormat = NumberFormat.getPercentInstance();
        this.humidity = percentFormat.format(humidity / 100.0);
        this.description = description;
        this.iconURL = "http://openweathermap.org/img/w/" + icon + ".png";
    }

    private static Calendar calendar(long timestamp) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestamp * 1000L);
        cal.setTimeZone(TimeZone.getDefault());
        return cal;
    }

    private static String convertTimeStampToDay(long timestamp) {
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE");
        return dayFormat.format(calendar(timestamp).getTime());
    }

    private static String convertTimeStampToTime(long timestamp) {
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        return timeFormat.format(calendar(timestamp).getTime());
    }

}

